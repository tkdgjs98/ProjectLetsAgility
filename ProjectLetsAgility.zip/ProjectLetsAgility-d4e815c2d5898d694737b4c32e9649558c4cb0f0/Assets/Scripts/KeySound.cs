﻿public class KeySound
{
    public static readonly string GameEnding_BGM = nameof(GameEnding_BGM);
    public static readonly string GamePlay_BGM = nameof(GamePlay_BGM);
    public static readonly string Intro_BGM = nameof(Intro_BGM);
    public static readonly string Main_BGM = nameof(Main_BGM);
    public static readonly string Fever_BGM = nameof(Fever_BGM);
    public static readonly string Effect_Click = nameof(Effect_Click);
    public static readonly string Effect_Fireworks = nameof(Effect_Fireworks);
    public static readonly string Effect_Food = nameof(Effect_Food);
    public static readonly string Effect_GameOver = nameof(Effect_GameOver);
    public static readonly string Effect_GameStart = nameof(Effect_GameStart);
    public static readonly string Effect_Heart = nameof(Effect_Heart);
    public static readonly string Effect_Hit = nameof(Effect_Hit);
    public static readonly string Effect_Hurt = nameof(Effect_Hurt);
    public static readonly string Effect_Jump = nameof(Effect_Jump);
    public static readonly string Effect_Mung = nameof(Effect_Mung);
    public static readonly string Effect_Pressed = nameof(Effect_Pressed);
    public static readonly string Effect_Slide = nameof(Effect_Slide);
}