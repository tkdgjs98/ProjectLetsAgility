﻿using System.Collections;
using System.Collections.Generic;
using DG.Tweening;
using TMPro;
using UnityEngine;
using Random = UnityEngine.Random;

public class GameManager : MonoBehaviour
{
    private static GameManager _instance;
    public int difficulty = 5;

    private bool isPause = false;
    private bool isMiniGame = false;
    public bool IsMiniGame => isMiniGame;
    public bool IsPause
    {
        get => isPause;

        set => isPause = value;
    }

    [SerializeField] private float beginMoveSpeed = 5f;
    private float _moveSpeed = 5f;
    public float MoveSpeed => _moveSpeed;
    
    private float _boostGaugeChargeAmount;
    public float BoostGaugeChargeAmount => _boostGaugeChargeAmount;

    private ConfigDataObject _configDataObject;

    private Player _player;
    private Map _map;
    private Person _person;
    private DogGirlFriend _dogGirlFriend;

    [SerializeField] private TextMeshProUGUI textMoveSpeed;
    [SerializeField] private ParticleSystem fireworksParticleSystem;
    
    
    public UIManager _uiManager;

    public List<KeyType> list = new List<KeyType>();
    private int cnt = 0;
    public int count => cnt;

    private float timeLimit = 5.0f;
    public float TimeLimit => timeLimit;

    public static GameManager Instance
    {
        get
        {
            if (_instance == null)
            {
                _instance = FindObjectOfType<GameManager>();
            }

            return _instance;
        }
    }

    private void Awake()
    {
        _configDataObject = ConfigDataObject.Instance;
        beginMoveSpeed = _moveSpeed = 0;
    }

    private void Start()
    {
        _player = FindObjectOfType<Player>(true);
        _map = FindObjectOfType<Map>(true);
        _dogGirlFriend = FindObjectOfType<DogGirlFriend>(true);
        _person = FindObjectOfType<Person>(true);

        _map.OnChangeMapCount += OnChangeMapCount;
        PauseMove();
    }

    private void OnChangeMapCount(int mapCount)
    {
    }

    private void Update()
    {
        if (GlobalFlowManager.Instance.FlowState != FlowState.Play)
        {
            return;
        }
        
        if (isPause)
        {
            return;
        }

        if (Input.GetKey(KeyCode.DownArrow))
        {
            _boostGaugeChargeAmount -= _configDataObject.subMoveSpeedPerSec * Time.deltaTime;
        }

        if (_player.CurrentState == PlayerState.Run)
        {
            _boostGaugeChargeAmount += _configDataObject.addMoveSpeedPerSec * Time.deltaTime;
        }
        else if (_player.CurrentState == PlayerState.Idle)
        {
            _boostGaugeChargeAmount = 0f;
        }

        _boostGaugeChargeAmount = Mathf.Max(0f, _boostGaugeChargeAmount);

        _moveSpeed = beginMoveSpeed + _boostGaugeChargeAmount;
        _moveSpeed = Mathf.Max(_moveSpeed, beginMoveSpeed);
        _moveSpeed = Mathf.Min(_moveSpeed, _configDataObject.maxMoveSpeed);
        if (textMoveSpeed != null)
        {
            textMoveSpeed.text = $"{_moveSpeed:0.0}";
        }
    }

    public void TakeDamage(float damage)
    {
        Debug.Log($"TakeDamage : {damage}");
        _boostGaugeChargeAmount -= _configDataObject.contactLostBoostGauge;
        _player.TakeDamage();
    }

    public void ShowMiniGame(Obstacle obstacle)
    {
        StartCoroutine(CoQuickTimeEventProcess(obstacle));
    }
    
    private IEnumerator CoQuickTimeEventProcess(Obstacle obstacle)
    {
        isPause = true;
        isMiniGame = true;
        Debug.Log("BeginQuickTimeEvent");
        
        // 미니게임 성공/실패 결과
        bool isSuccess = false;
        timeLimit = 5.0f;
        cnt = 0;

        PauseMove();

        // 미니게임 랜덤 방향키 설정
        for(int i = 0; i < difficulty; i++)
        {
            KeyType key = (KeyType) Random.Range(0, 4);
            list.Add(key);
        }

        while (true)
        {
            KeyType key = KeyType.None;
            timeLimit -= Time.deltaTime;
            _uiManager.OnMiniGame();

            if (Input.GetKeyDown(KeyCode.UpArrow))     key = KeyType.Up;
            else if (Input.GetKeyDown(KeyCode.RightArrow))  key = KeyType.Right;
            else if (Input.GetKeyDown(KeyCode.DownArrow))   key = KeyType.Down;
            else if (Input.GetKeyDown(KeyCode.LeftArrow))   key = KeyType.Left;

            if(key != KeyType.None)
            {
                if (key == list[cnt])
                {
                    cnt++;
                }
                else
                {
                    // 미니게임 실패 Key 잘못 입력
                    isSuccess = false;
                    break;
                }
            }

            // 미니게임 성공 시
            if (cnt == list.Count)
            {
                // 장애물 제거 or 파괴
                Debug.Log("Success");
                isSuccess = true;
                break;
            }

            // 미니게임 실패 시 (시간 제한 초과)
            if (timeLimit <= 0)
            {
                isSuccess = false;
                break;
            }

            string str = "result : ";
            foreach (var i in list)
            {
                
                str += i + " / ";
            }
            
            Debug.Log(str);
            Debug.Log($"LeftTime : {timeLimit}");
            yield return null;
        }

        // 실패
        if (!isSuccess)
        {
            obstacle.Crash();
        }
        list.Clear();
        isMiniGame = false;
        _uiManager.OnMiniGame();
        ResumeMove();
    }

    public void PauseMove()
    {
        isPause = true;
        _moveSpeed = 0f;
    }

    public void ResumeMove()
    {
        isPause = false;
    }

    public void ShowIntro()
    {
        Debug.Log("ShowIntro");
        StartCoroutine(CoIntroProcess());
    }

    private Vector3 originMainCamPos;
    private float originMainCamSize;

    private IEnumerator CoIntroProcess()
    {
        Debug.Log("CoIntroProcess");
        FadeCanvas.FadeIn();
        
        _player.Animator.Play("Idle");
        var mainCam = Camera.main;
        originMainCamPos = mainCam.transform.position;
        originMainCamSize = mainCam.orthographicSize;

        var playerPos = _player.transform.position;
        playerPos.z = -10f;
        playerPos.y += 1f;
        playerPos.x += 2f;
        mainCam.transform.position = playerPos;
        mainCam.orthographicSize = 2.5f;
        Debug.Log("Why is the view so..");
        // print: Why is the view so..
        yield return new WaitForSeconds(2f);

        yield return BackToOrigin(0.5f);
        Debug.Log("What the..");
        // print: What the..

        yield return new WaitForSeconds(2f);
        mainCam.transform.DOMove(playerPos, 0.3f);
        mainCam.DOOrthoSize(2.5f, 0.3f);
        Debug.Log("What the!!!!!!");
        // print: What the!!!!!!!!!!!!
        yield return new WaitForSeconds(2f);
        
        // 암컷 등장
        _dogGirlFriend.Show();
        yield return BackToOrigin(0.5f);

        yield return new WaitForSeconds(1f);
        // 인간 Shocked
        _person.PlayAnimation(Person.Animation.Surprise);
        // 강아지 Idle 무표정
        
        _dogGirlFriend.PlayAnimation(DogGirlFriend.Animation.Run);
        _dogGirlFriend.transform.DOMoveX(15f, 4f);
        yield return new WaitForSeconds(2f);

        _person.PlayAnimation(Person.Animation.Run);
        _person.transform.DOMoveX(8f, 3f).SetEase(Ease.Linear);
        yield return new WaitForSeconds(1.5f);
        // 강아지 Shoking 
        Debug.Log("No no no... !!");
        // 무표정 Idle
        yield return new WaitForSeconds(1.5f);
        Debug.Log("I need to follow him now!!");
        yield return new WaitForSeconds(1.5f);
        Debug.Log("If I won this competition..");
        yield return new WaitForSeconds(1.5f);
        Debug.Log("I could go back to my body.");

        // Tutorial
        yield return new WaitForSeconds(2f);
        GlobalFlowManager.Instance.GameStart();
    }

    private IEnumerator BackToOrigin(float duration)
    {
        var mainCam = Camera.main;
        mainCam.transform.DOMove(originMainCamPos, duration);
        mainCam.DOOrthoSize(originMainCamSize, duration);
        yield return new WaitForSeconds(duration + 0.1f);
    }

    public void GameStart()
    {
        Debug.Log("GameStart");
        FadeCanvas.FadeIn();
        var personPos = _person.transform.position;
        personPos.x = 8f;
        _person.PlayAnimation(Person.Animation.Run);
        _person.transform.position = personPos;
        
        beginMoveSpeed = _configDataObject.beginMoveSpeed;
        _moveSpeed = beginMoveSpeed;
        ResumeMove();
    }

    public void GameClear()
    {
        Debug.Log("GameClear");
        _player.ChangeState(PlayerState.Idle);
        PauseMove();
        GlobalFlowManager.Instance.Ending();
    }

    public void ShowEnding()
    {
        StartCoroutine(CoEndingProcess());
    }

    private IEnumerator CoEndingProcess()
    {
        yield return null;
        _player.Rigidbody2D.isKinematic = true;

        var personPos = _person.transform.position;
        personPos.x = 8f;
        _person.PlayAnimation(Person.Animation.Run);
        _person.transform.position = personPos;
        _person.transform.DOMoveX(15f, 1.5f).SetEase(Ease.Linear);
        fireworksParticleSystem.Play();
        
        _player.Animator.Play("Run");
        _player.transform.DOMove(new Vector3(0f, -3.19f, 0f), 2f).SetEase(Ease.Linear);
        yield return new WaitForSeconds(2f);
        _player.PlayAnimation(Player.Animation.Idle);
        Debug.Log("?");
        yield return new WaitForSeconds(1.5f);
        Debug.Log("Why isn't there any changes..?");
        yield return new WaitForSeconds(1.5f);
        Debug.Log("Isn't it a cliche!!?");
        // 강아지 충격
        yield return new WaitForSeconds(1.5f);
        
        _dogGirlFriend.Show();
        _dogGirlFriend.PlayAnimation(DogGirlFriend.Animation.Run);
        var dogGirlFriendPos = _dogGirlFriend.transform.position;
        dogGirlFriendPos.x = 13f;
        Debug.Log("!");

        _dogGirlFriend.transform.position = dogGirlFriendPos;
        _dogGirlFriend.transform.localScale = new Vector3(-1f, 1f, 1f);
        _dogGirlFriend.transform.DOMoveX(5f, 2f).SetEase(Ease.Linear);
        yield return new WaitForSeconds(2f);
        _dogGirlFriend.PlayAnimation(DogGirlFriend.Animation.Idle);
        
        // 강아지 무표정
        _player.transform.DOMoveX(2f, 2f).SetEase(Ease.Linear);
        _player.PlayAnimation(Player.Animation.Run);
        // PlayBGM Ending
        yield return new WaitForSeconds(2f);
        _player.PlayAnimation(Player.Animation.Idle);
        Debug.Log("Don't know why..");
        Debug.Log("\u2665"); // heart
        yield return new WaitForSeconds(2f);
        
        _dogGirlFriend.transform.localScale = new Vector3(1f, 1f, 1f);
        _dogGirlFriend.PlayAnimation(DogGirlFriend.Animation.Run);
        _dogGirlFriend.transform.DOMoveX(17f, 4f).SetEase(Ease.Linear);
        _player.PlayAnimation(Player.Animation.Run);
        _player.transform.DOMoveX(15f, 4f).SetEase(Ease.Linear);
        
        // Show Toast THE END
    }

    public void GameOver()
    {
        Debug.Log("GameOver");
    }
}